
CREATE TABLE WeatherData (
Id INT IDENTITY PRIMARY KEY,
Location NVARCHAR(100),
Temperature FLOAT,
Humidity FLOAT,
AirQuality FLOAT,
RecordedAt DATETIME
);

CREATE TABLE AlertSubscription (
Id INT IDENTITY PRIMARY KEY,
Email NVARCHAR(150),
Location NVARCHAR(100),
TemperatureThreshold FLOAT
);
