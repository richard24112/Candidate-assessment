using Microsoft.EntityFrameworkCore;
using WeatherService.API.Data;
using WeatherService.API.Models;

namespace WeatherService.API.Repositories;

public class WeatherRepository
{
    private readonly WeatherDbContext _context;

    public WeatherRepository(WeatherDbContext context)
    {
        _context = context;
    }

    public async Task SaveWeatherAsync(WeatherData data)
    {
        _context.WeatherData.Add(data);
        await _context.SaveChangesAsync();
    }

    public async Task<List<WeatherData>> GetByLocation(string location)
    {
        return await _context.WeatherData
            .Where(x => x.Location == location)
            .ToListAsync();
    }
}