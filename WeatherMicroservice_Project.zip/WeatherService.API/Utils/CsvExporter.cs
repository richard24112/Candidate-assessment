using CsvHelper;
using System.Globalization;
using WeatherService.API.Models;

namespace WeatherService.API.Utils;

public class CsvExporter
{
    public byte[] Export(List<WeatherData> data)
    {
        using var memoryStream = new MemoryStream();
        using var writer = new StreamWriter(memoryStream);
        using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);

        csv.WriteRecords(data);
        writer.Flush();

        return memoryStream.ToArray();
    }
}