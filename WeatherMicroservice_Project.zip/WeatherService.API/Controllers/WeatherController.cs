using Microsoft.AspNetCore.Mvc;
using WeatherService.API.Models;
using WeatherService.API.Repositories;
using WeatherService.API.Services;

namespace WeatherService.API.Controllers;

[ApiController]
[Route("api/weather")]
public class WeatherController : ControllerBase
{
    private readonly WeatherService _weatherService;
    private readonly WeatherRepository _repository;

    public WeatherController(WeatherService weatherService, WeatherRepository repository)
    {
        _weatherService = weatherService;
        _repository = repository;
    }

    [HttpGet("current/{location}")]
    public async Task<IActionResult> GetCurrentWeather(string location)
    {
        var temp = await _weatherService.GetTemperature(location);

        var data = new WeatherData
        {
            Location = location,
            Temperature = temp,
            RecordedAt = DateTime.UtcNow
        };

        await _repository.SaveWeatherAsync(data);

        return Ok(data);
    }

    [HttpGet("history/{location}")]
    public async Task<IActionResult> GetHistory(string location)
    {
        var history = await _repository.GetByLocation(location);
        return Ok(history);
    }
}