using Microsoft.EntityFrameworkCore;
using WeatherService.API.Models;

namespace WeatherService.API.Data;

public class WeatherDbContext : DbContext
{
    public WeatherDbContext(DbContextOptions<WeatherDbContext> options) : base(options) {}

    public DbSet<WeatherData> WeatherData { get; set; }
    public DbSet<AlertSubscription> AlertSubscriptions { get; set; }
}