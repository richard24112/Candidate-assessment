using Newtonsoft.Json;

namespace WeatherService.API.Services;

public class WeatherService
{
    private readonly HttpClient _httpClient;

    public WeatherService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<double> GetTemperature(string location)
    {
        var url = $"https://api.openweathermap.org/data/2.5/weather?q={location}&appid=YOUR_API_KEY&units=metric";
        var response = await _httpClient.GetStringAsync(url);
        dynamic data = JsonConvert.DeserializeObject(response);
        return data.main.temp;
    }
}