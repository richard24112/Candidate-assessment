namespace WeatherService.API.Models;

public class AlertSubscription
{
    public int Id { get; set; }
    public string Email { get; set; }
    public string Location { get; set; }
    public double TemperatureThreshold { get; set; }
}