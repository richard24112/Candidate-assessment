namespace WeatherService.API.Models;

public class WeatherData
{
    public int Id { get; set; }
    public string Location { get; set; }
    public double Temperature { get; set; }
    public double Humidity { get; set; }
    public double AirQuality { get; set; }
    public DateTime RecordedAt { get; set; }
}