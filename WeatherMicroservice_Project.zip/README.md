# Weather Microservice (.NET 8)

## Overview
Weather microservice built using ASP.NET Core Web API that integrates with OpenWeatherMap and stores weather data in SQL Server.

## Features
- Get current weather
- Store weather history
- Export weather data to CSV
- Swagger API documentation
- Docker support
- CI/CD with GitHub Actions

## Run Locally
dotnet restore
dotnet build
dotnet run

Swagger:
https://localhost:5001/swagger

## API Endpoints

GET /api/weather/current/{location}
GET /api/weather/history/{location}