# Architecture

Client -> Weather API -> Database
                    -> OpenWeather API

Components
- Controller Layer
- Service Layer
- Repository Layer
- SQL Database
- External Weather API

Resiliency:
- Polly retry policy

Security:
- HTTPS
- Input validation

Deployment:
- Docker
- GitHub Actions CI/CD